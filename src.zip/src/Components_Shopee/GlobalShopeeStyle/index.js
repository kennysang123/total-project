//import React from "react";
import "./GlobalShopee.scss";

export default function GlobalShopeeStyles({ children }) {
  return children;
}
